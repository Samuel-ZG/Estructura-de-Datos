#pragma once
#include <string>

using namespace std;

class TipoDato
{
public:
	int id;
	string descripcion;
public:
	TipoDato(void);
	~TipoDato(void);
};

