#include "StdAfx.h"
#include "TipoDato.h"


TipoDato::TipoDato(void)
{
}


TipoDato::~TipoDato(void)
{
}
