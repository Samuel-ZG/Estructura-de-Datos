#include "stdafx.h"
#include <iostream>
#include "Pila.h"
#include "TipoDato.h"
#include <string>

using namespace std;
int main()
{
	TipoDato cars;
	Pila car;
	int option = 0;
	do {
		cout << "\Menu" << endl;
		cout << "1. Push car" << endl;
		cout << "2. Pop car" << endl;
		cout << "3. View top car" << endl;
		cout << "4. Clean cars" << endl;
		cout << "5. View cars" << endl;
		cout << "0. Exit" << endl;
		cout << "Enter your option: ";
		cin >> option;
		switch (option) {
			case 1:
				cout << "Ingrese el tipo de auto: ";
				cin.ignore();
				getline(cin, cars.descripcion);
				cout << "Ingrese el numero de chasis del auto:";
				cin >> cars.id;
				car.Apilar(cars);
				break;
			case 2:
				car.Desapilar();
				break;
			case 3:
				car.CimaPila(cars);
				break;
			case 4:
				car.LimpiarPila();
				break;
			case 5:
				car.VerPila();
				break;
			case 0:
				cout << "Saliendo...." << endl;
				break;
			default:
				cout << "Invalido." << endl;
				break;
		}
	} while (option != 0);
}
