#include <iostream>
#include "Circulo.h"
#include "Rectangulo.h"
#include "Trapecio.h"

using namespace std;

int main()
{
    int op;
    Circulo circulito;
    Rectangulo rectangulito;
    Trapecio trapecito;

    do {
        cout << "\n --- Menu --- " << endl;
        cout << "\n1. Calcular Area de Circulo";
        cout << "\n2. Calcular Area de Rectangulo";
        cout << "\n3. Calcular Area de Trapecio";
        cout << "\n0. Salir\n";
        cout << "\nElija la opcion que desee: ";

        cin >> op;

        switch (op) {
        case 1:
            float radio;

            cout << "\nPara calcular el area del circulo. \n\nIngrese el radio: ";
            cin >> radio;

            circulito.set_radio(radio);

            cout << "\t El area es: " << circulito.CalcularArea();
            break;

        case 2:
            float base, altura;

            cout << "\nPara calcular el area del rectangulo.\n";
            cout << "\nIngrese la base: ";
            cin >> base;
            cout << "Ingrese la altura : ";
            cin >> altura;

            rectangulito.set_base(base);
            rectangulito.set_altura(altura);

            cout << "\t El area es: " << rectangulito.CalcularArea();
            break;

        case 3:
            float baseMenor, baseMayor, alturaT;

            cout << "\nPara calcular el area del trapecio.\n";
            cout << "\nIngrese la base mayor: ";
            cin >> baseMayor;
            cout << "Ingrese la base menor: ";
            cin >> baseMenor;
            cout << "Ingrese la altura: ";
            cin >> alturaT;

            trapecito.set_BaseMayor(baseMayor);
            trapecito.set_BaseMenor(baseMenor);
            trapecito.set_AlturaT(alturaT);

            cout << "\t El area es: " << trapecito.CalcularArea();
            break;

        case 0:
            cout << "\nHasta pronto";
            break;

        default:
            cout << "\nOpcion invalida";
            break;
        }

        cout << endl;

    } while (op != 0);

    return 0;
}