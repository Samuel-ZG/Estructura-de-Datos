#include "Trapecio.h"


Trapecio::Trapecio() {
}

void Trapecio::set_BaseMenor(float baseMenor) {
	BaseMenor = baseMenor;
}

void Trapecio::set_BaseMayor(float baseMayor) {
	BaseMayor = baseMayor;
}

void Trapecio::set_AlturaT(float alturaT) {
	AlturaT = alturaT;
}

float Trapecio::get_BaseMenor() {
	return BaseMenor;
}

float Trapecio::get_BaseMayor() {
	return BaseMayor;
}

float Trapecio::get_AlturaT() {
	return AlturaT;
}

double Trapecio::CalcularArea() {
	return (((BaseMayor + BaseMenor) * 2) / 2);
}
