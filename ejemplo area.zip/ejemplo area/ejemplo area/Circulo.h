#pragma once
class Circulo
{
	private:
		float Radio;
	public:
		Circulo();
		float get_radio();
		void set_radio(float radio);
		double CalcularArea();
};