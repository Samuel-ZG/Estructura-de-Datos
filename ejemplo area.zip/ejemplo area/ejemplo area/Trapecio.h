#pragma once
class Trapecio
{
	private:
		float BaseMenor;
		float BaseMayor;
		float AlturaT;
	public:
		Trapecio();
		void set_BaseMenor(float baseMenor);
		void set_BaseMayor(float baseMayor);
		void set_AlturaT(float alturaT);
		float get_BaseMenor();
		float get_BaseMayor();
		float get_AlturaT();
		double CalcularArea();
};

