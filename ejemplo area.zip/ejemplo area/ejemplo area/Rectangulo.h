#pragma once
class Rectangulo
{
	private:
		float Base;
		float Altura;
	public:
		Rectangulo();
		void set_base(float base);
		void set_altura(float altura);
		float get_base();
		float get_altura();
		double CalcularArea();
};
