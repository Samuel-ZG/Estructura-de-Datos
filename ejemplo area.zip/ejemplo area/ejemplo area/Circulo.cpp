#include "Circulo.h"


Circulo::Circulo() {
}

float Circulo::get_radio() {
	return Radio;
}

void Circulo::set_radio(float radio) {
	Radio = radio;
}

double Circulo::CalcularArea() {
	return (Radio * Radio * 3.141516);
}
