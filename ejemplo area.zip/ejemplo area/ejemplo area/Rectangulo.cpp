#include "Rectangulo.h"


Rectangulo::Rectangulo() {
}

void Rectangulo::set_base(float base) {
	Base = base;
}

void Rectangulo::set_altura(float altura) {
	Altura = altura;
}

float Rectangulo::get_base() {
	return Base;
}

float Rectangulo::get_altura() {
	return Altura;
}

double Rectangulo::CalcularArea() {
	return (Base * Altura);
}