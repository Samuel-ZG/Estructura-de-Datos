#include "Pila.h"
#include <iostream>
#include <string>

using namespace std;

void Pila::push() {
    string valor;
    string valor2;
    Nodo* aux = new Nodo;
    // ubica espacio de memoria para crear una instancia del Nodo: operator new (Nodo))
   // y entonces construye un objeto en el nuevo espacio ubicado
    system("cls");
    cout << "Ingresa el nombre de la cancion: ";
    cin.ignore();
    getline(cin, valor);
    cout << "Ingresa el autor de la cancion: ";
    cin.ignore();
    getline(cin, valor2);
    aux->autor = valor;
    aux->nombre = valor2;
    aux->sig = NULL;
    //Accede al elemento dato de Nodo y le asigna valor.
    if (cima != NULL)
        aux->sig = cima;
    cima = aux;
    cout << "Nueva cancion insertada en la Pila!\n";
    system("pause");
}

void Pila::pop() {
    Nodo* temp = new Nodo;
    if (cima == NULL) {
        system("cls");
        cout << "\nLa Pila esta vacia!\n\n";
        system("pause");
    }
    else {
        temp = cima;
        cima = cima->sig;
        system("cls");
        cout << "\nLa cancion eliminada es: " << temp->nombre << " - " << temp->autor << "\n" << endl;
        delete temp;
        system("pause");
    }
}

void Pila::show() {
    Nodo* aux1 = cima;
    if (cima == NULL) {
        system("cls");
        cout << "\nLa Pila esta vacia!\n\n";
        system("pause");
    }
    else {
        system("cls");
        cout << "Canciones:\n" << endl;
        while (aux1 != NULL) {
            cout << aux1->nombre << " - " << aux1->autor << "\n" << endl;
            aux1 = aux1->sig;
        }
        system("pause");
    }
}

void Pila::top() {
    Nodo* aux1 = cima;
    if (cima == NULL) {
        system("cls");
        cout << "\nLa Pila esta vacia!\n\n";
        system("pause");
    }
    else {
        system("cls");
        cout << "Primera cancion que se reproducira:\n" << endl;
        cout << aux1->nombre << " - " << aux1->autor << "\n" << endl;
        system("pause");
    }
}

void Pila::size() {
    Nodo* aux1 = cima;
    if (cima == NULL) {
        system("cls");
        cout << "\nLa Pila esta vacia!\n\n";
        system("pause");
    }
    else {
        int contador = 0;
        while (aux1) {
            contador++;
            aux1 = aux1->sig;
        }
        system("cls");
        cout << "El tamano de la Pila es: '" << contador << "'\n" << endl;
        system("pause");
    }
}
