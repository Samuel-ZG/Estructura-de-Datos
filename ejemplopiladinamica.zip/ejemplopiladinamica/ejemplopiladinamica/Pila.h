#pragma once
#include "Nodo.h"

class Pila {
		Nodo* cima;
public:
		Pila() {
			cima = NULL;
		}
		void push();
		void pop();
		void show();
		void top();
		void size();
	};