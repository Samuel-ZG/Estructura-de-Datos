
#pragma once
#include <string>

using namespace std;

class Nodo
{
	public:
		string nombre;
		string autor;
		Nodo* sig;
	};

