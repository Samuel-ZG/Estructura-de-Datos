#pragma once
#include <string>

using namespace std;

#define MAX 100

class Colae { 
	private: 
		string info[MAX];
		int ini, fin;
	public: 
		Colae (void); 
		bool Encolar (string Valor); 
		bool Desencolar (void); 
		bool PrimeroCola (string &Valor); 
		bool ColaVacia (void);
		void mostrar (void);
};


