// cola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include "Colae.h"

#define MAX 100

using namespace std;

void main()
{
	Colae cola;
	int opcion = 0;
	string Texto;

	do {
		cout << "\n\tMenu\n";
		cout << "1. La cola esta vacia?\n";
		cout << "2. Encolar\n";
		cout << "3. Desencolar\n";
		cout << "4. Mostrar\n";
		cout << "5. Primero de la cola\n";
		cout << "6. Finalizar\n";
		cout << "Opcion: ";
		cin >> opcion;

		switch (opcion)
		{
		case 1:
			if (cola.ColaVacia())
				cout << "\nSi, la cola esta vacia.\n";
			else
				cout << "\nNo, no esta vacia.";
			break;
		case 2:
			cout << "Ingrese el dato: \n";
			cin >> Texto;

			if (!cola.Encolar(Texto))
				cola.mostrar();
			else
				cout << "Error\n";
			break;
		case 3:
			if (!cola.Desencolar())
				cola.mostrar();
			else
				cout << "Error";
			break;
		case 4:
			cout << "La cola es:\n";
			cola.mostrar();
			break;
		case 5:
			if (!cola.PrimeroCola(Texto))
				cout << "Valor: " << Texto;
			break;
		case 0:
			cout << "\nSaliendo...";
			break;
		default:
			cout << "Opcion invalida.\n";
			break;
		}
	} while (opcion != 0);
}